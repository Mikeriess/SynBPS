# SynBPS
 Synthetic Business Process Simulation


# Todos
- Publish on main pypi
- Extend HOMC to include h > 4
- Add ML example to example notebook
- Create a function for running experiments to abstract away for-loop